const a = parseInt(prompt("Podaj pierwszą liczbę"));
const b = parseInt(prompt("Podaj drugą liczbę"));
const c = a / b;

document.write(`1. ${a / 2}<br>2. ${a / b}<br>3. ${1 / 1}<br>4. ${a / (b / c)}`);