use std::fs;
use std::env;
use std::env::consts;
use std::collections::HashMap;
use std::sync::Arc;

use actix_web::middleware::Logger;
use actix_web::{App, HttpServer, Responder, web};
use reqwest::Client;
use tokio::sync::RwLock;
use serde::{Serialize, Deserialize};
use tokio::time::Duration;
use tokio::time;
use include_dir::{include_dir, Dir};

type AppState = Arc<RwLock<State>>;

static INDEX: &str = include_str!("../static/index.html");
static ASSETS: Dir = include_dir!("./static/assets");

#[derive(Serialize, Deserialize)]
struct Anime {
  pub image_url: String,
  pub rating: f32,
  pub href: String,
}

#[derive(Serialize, Deserialize)]
struct Comment {
  pub user: String,
  pub comment: String,
  pub date: u64,
  pub rating: f32,
}

#[derive(Serialize, Deserialize)]
struct Contact {
  pub user: String,
  pub email: String,
  pub message: String,
}

#[derive(Serialize, Deserialize, Default)]
struct State {
  pub animes: HashMap<String, Anime>,
  pub comments: Vec<Comment>,
  pub contact_entries: Vec<Contact>,
  pub ran_before: bool,

  #[serde(skip)]
  pub path: String,
}

impl State {
  pub fn new(path: String) -> Self {
    let mut state = match fs::read_to_string(&path) {
      Ok(state) => serde_json::from_str(&state).unwrap_or_default(),
      Err(_) => State::default(),
    };

    state.path = path;
    state
  }

  pub fn write(&self) {
    let state = serde_json::to_string(&self).expect("Failed to serialize state");
    fs::write(&self.path, state).expect("Failed to write state");
  }
}

#[tokio::main]
async fn main() -> std::io::Result<()> {
  let app_data = match consts::OS {
    "windows" => env::var("APPDATA").unwrap(),
    "linux" => env::var("HOME").unwrap(),
    _ => panic!("Unsupported OS"),
  };

  env::set_var("RUST_LOG", "info");
  pretty_env_logger::init();

  let path = format!("{}/{}", app_data, "/state.json");
  let state = State::new(path);
  let ran_before = state.ran_before;

  let state = Arc::new(RwLock::new(state));

  if ran_before {
    log::info!("Ran before, fetching data in background...");
    tokio::spawn(refetch(state.clone()));
  } else {
    log::info!("First time running, fetching data...");
    refetch(state.clone()).await;
  }

  tokio::spawn(async {
    time::sleep(Duration::from_secs(1)).await;

    log::info!("Opening browser at localhost:8080");
    open::that("localhost:8080").expect("Failed to open browser");
  });

  
  HttpServer::new(move || {
    let logger = Logger::default();
    App::new()
      .wrap(logger)
      .wrap(actix_cors::Cors::permissive())
      .app_data(web::Data::new(state.clone()))
      .route("/assets/{path:.*}", web::get().to(asset))
      .default_service(web::get().to(index))
      .service(web::scope("/api")
        .route("/entries", web::get().to(entries))
        .route("/contact", web::post().to(contact))
        .route("/ratings", web::get().to(comments))
        .route("/ratings", web::post().to(comment))
      )
  })
  .bind(("10.25.70.35", 8080))?
  .run()
  .await
}

async fn refetch(state: AppState) {
  log::info!("Refetching data...");

  let client = Client::new();
  let res = client.get("https://myanimelist.net/topanime.php")
    .send()
    .await
    .expect("Failed to fetch data")
    .text()
    .await
    .expect("Failed to weebout");

  let mut lines = res.lines();
  let mut state = state.write().await;
  state.animes.clear();

  loop {
    let line = match lines.next() {
      Some(line) => line,
      None => break,
    };

    if !line.contains(r#"<tr class="ranking-list">"#) {
      continue;
    }

    let link_line = match lines.nth(4) {
      Some(line) => line,
      None => break,
    };

    let anime_name_pos = link_line.find(r#"href="https://myanimelist.net/anime/"#).expect("anime name pos");
    let link_line = &link_line[anime_name_pos + 36..];

    let href = link_line.split(r#"""#).next().expect("href");

    let name = link_line.split("/").nth(1).expect("name");
    let name = name.split(r#"""#).next().expect("name");
    
    let img_line = match lines.next() {
      Some(line) => line,
      None => break,
    };

    let img_line = img_line.split(r#"https://cdn.myanimelist.net/r/50x70/images/anime/"#).nth(1).expect("img line");
    let img_id = img_line.split(".").next().expect("img id");

    let mut rating: f32 = 0.0;
    loop {
      let line = match lines.next() {
        Some(line) => line,
        None => break,
      };

      let pos = match line.find("on score-label score-") {
        Some(pos) => pos,
        None => continue,
      };

      let rating_raw = &line[pos + 24..];
      let rating_raw = rating_raw.split("<").next().expect("rating");

      rating = rating_raw.parse().expect("rating");
      break;
    }

    let title = name.split("_").filter(|s| !s.is_empty()).collect::<Vec<_>>().join(" ");
    state.animes.insert(title, Anime {
      image_url: format!("https://cdn.myanimelist.net/images/anime/{}.jpg", img_id),
      rating,
      href: href.to_string(),
    });
  }

  if !state.ran_before {
    state.ran_before = true;
  }

  log::info!("Done fetching data");
  state.write();
}

async fn entries(state: web::Data<AppState>) -> impl Responder {
  let state = state.read().await;

  let body = serde_json::to_string(&state.animes).expect("Failed to serialize animes");
  actix_web::HttpResponse::Ok().body(body)
}

async fn contact(state: web::Data<AppState>, contact: web::Json<Contact>) -> impl Responder {
  let mut state = state.write().await;
  log::info!("New contact entry from {}", contact.user);

  state.contact_entries.push(contact.into_inner());
  state.write();
  
  actix_web::HttpResponse::Ok().body("ok")
}

async fn comments(state: web::Data<AppState>) -> impl Responder {
  let state = state.read().await;

  let body = serde_json::to_string(&state.comments).expect("Failed to serialize comments");
  actix_web::HttpResponse::Ok().body(body)
}

#[derive(Deserialize)]
struct NewComment {
  pub user: String,
  pub comment: String,
  pub rating: f32,
}

async fn comment(state: web::Data<AppState>, comment: web::Json<NewComment>) -> impl Responder {
  let mut state = state.write().await;
  log::info!("New comment from {}", comment.user);

  let date = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_secs();
  state.comments.push(Comment {
    user: comment.user.clone(),
    comment: comment.comment.clone(),
    rating: comment.rating,
    date,
  });

  state.write();
  actix_web::HttpResponse::Ok().body(date.to_string())
}

async fn asset(path: web::Path<String>) -> impl Responder {
  let path = path.into_inner();
  let asset = ASSETS.get_file(&path).expect("Failed to get asset").contents();
  
  if !path.ends_with(".js") {
    return actix_web::HttpResponse::Ok().body(asset);
  }

  actix_web::HttpResponse::Ok()
    .content_type("application/javascript")
    .body(asset)
}

async fn index() -> impl Responder {
  actix_web::HttpResponse::Ok().body(INDEX)
}
